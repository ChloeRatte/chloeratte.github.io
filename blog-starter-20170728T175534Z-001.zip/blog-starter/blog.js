class BlogEntry {
//name, blogText
}

function addEntryToBlog() {
  //Create new blog entry
  var blogEntry = new BlogEntry(/*pass in name and blog text as parameters*/));

  //Add the new entry, name and date to the blog
  createBlogEntryElement(blogEntry);
  createFooterElement(blogEntry);

  //Clear the inputs

}

function createBlogEntryElement(blogEntry) {

}

function createFooterElement(blogEntry) {

}
